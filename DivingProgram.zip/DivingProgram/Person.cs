﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DivingProgram
{
    internal class Person
    {
        private string firstName;
        private string lastName;
        private string email;
        private string password;
        private DateTime birthDate;

        public Person (string firatName, string lastName, string email, string password, DateTime birthDate)
        {
            this.firstName = firatName;
            this.lastName = lastName;
            this.email = email;
            this.password = password;
            this.birthDate = birthDate;
        }

    



    }
}
